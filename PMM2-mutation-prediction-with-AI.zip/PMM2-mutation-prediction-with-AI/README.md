# PMM2 Mutation Prediction with AI

## Overview
This repository contains code and data for predicting mutations in the PMM2 gene using advanced artificial intelligence (AI) and machine learning (ML) techniques. The project leverages supervised learning models, including logistic regression, decision trees, random forests, support vector machines, and neural networks. The dataset has been processed using SMOTE for balancing.

The ultimate goal of this project is to enable accurate predictions that can support research in genetic mutation studies and disease modeling.

---

## Directory Structure

